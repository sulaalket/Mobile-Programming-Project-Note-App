package com.example.noteapptest2;


//import files


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class editnoteactivity extends AppCompatActivity {

    //setting the variables that will serve to obtain the data from the xml editnoteactivity
    //in the layouts and google firebase

    Intent data;
    EditText medittitleofnote, meditcontentofnote;
    FloatingActionButton msaveditnote;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editnoteactivity);

        //obtaining the values from the xml or firebase

        medittitleofnote = findViewById(R.id.edittitleofnote);
        meditcontentofnote = findViewById(R.id.editcontentofnote);
        msaveditnote = findViewById(R.id.saveditnote);

        data = getIntent();

        //initializing the instances in firebase

        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        //declaring title and content variable to represent the variables
        //located in firebasemodel java file

        String notetitle = data.getStringExtra("title");
        String notecontent = data.getStringExtra("content");

        //setting their values in the respective upper declared variables

        medittitleofnote.setText(notetitle);
        meditcontentofnote.setText(notecontent);

        //the development of the save icon

        msaveditnote.setOnClickListener(v -> {

            //it will be saving the title
            //and the new content

            String newtitle = medittitleofnote.getText().toString();
            String newcontent = meditcontentofnote.getText().toString();


            //condition checking to have both title and content filled

            if (newtitle.isEmpty() || newcontent.isEmpty()) {
                Toast.makeText(editnoteactivity.this, "Both fields are required", Toast.LENGTH_SHORT).show();
                return;
            }

            //if everything is okay, we access the firebase

            DocumentReference documentReference = firebaseFirestore.collection("notes").document(firebaseAuth.getCurrentUser().getUid()).collection("myNotes").document(data.getStringExtra("noteId"));
            Map<String, Object> note = new HashMap<>(); //Using HashMaps to store the values as below
            note.put("title", newtitle);
            note.put("content", newcontent);

            documentReference.set(note).addOnSuccessListener(aVoid ->
                            Toast.makeText(editnoteactivity.this, "Note Updated", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e ->
                            Toast.makeText(editnoteactivity.this, "Failed to update note", Toast.LENGTH_SHORT).show());
            startActivity(new Intent(editnoteactivity.this, notesActivity.class));
        });


        Toolbar toolbar = findViewById(R.id.toolbarofeditnote);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }


    //clicking the back button to be back at the main page/home
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
